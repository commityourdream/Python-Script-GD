aName=input("Enter Your Name")
print("Your name in all capital is",aName.upper(),"and has length",len(aName))
